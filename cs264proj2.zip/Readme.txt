You will be prompted to enter a term (n) in Fibonacci's Sequence.

Once you have entered a valid value for n (within the given range 0 to 46), the nth term
in the sequence will be printed as well as a the first 10 (if possible) numbers in the sequence leading up to the nth term.